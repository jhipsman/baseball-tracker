# GameChanger Android: scoring and game tracking analysis

Analysis date: October 29, 2026. Scope: six DEX files, the binary manifest, resource table, and the assets-directory screenshot; static analysis only. Updated after the second upload. No implementation or repository edits.

## What this pass establishes

GameChanger's supplied client code represents baseball scoring as a stream of structured events, with grouped play transactions, provisional runner resolution, undo/redo, local event storage, and asynchronous synchronization. The scoring screen is one consumer of this state; line scores, play-by-play, player stats, spray charts, and alerts have separate interfaces.

This is a substantial architectural finding for Diamond Program: extending the existing run-entry screen into pitch-by-pitch scoring would require a game model that can represent the details and corrections of a whole play.

**Second-upload finding:** `classes4.dex` contains the missing baseball bridge and state/event definitions. That bridge explicitly loads `assets/entrypoint.js` and invokes JavaScript scoring methods through J2V8. We can now recover the Android-side models and bridge contract, but the full rules calculations still require the JavaScript assets. Section 14 records the new findings. Earlier evidence IDs E02–E19 remain valid.

## Evidence and confidence

- **Code-confirmed:** a class, field, method invocation, constant reference, or branch is present in the supplied DEX files. This proves the code exists, not that a particular account or feature configuration enables it.
- **Resource-confirmed:** text exists in the supplied resource table. It can describe intended behavior, but may belong to an inactive, gated, or older feature.
- **Inference:** an architectural interpretation or suggestion for this project. These are identified below.
- **Unknown:** implementation or runtime behavior that the supplied files cannot establish.

Evidence IDs E02–E19 resolve to class names, methods, DEX byte offsets, and instruction references in `evidence-index.json`. Resource references below are global string-pool indices in `selected-resource-evidence.json`. They are not Android resource IDs. `observed-event-values.json` lists referenced constants; it is not an exhaustive enumeration of the initially missing engine. The new `engine-models.json` also records constants from the recovered definitions.

## 1. Inputs and integrity

The binary manifest identifies `com.gc.teammanager`, version **2026.41.0.0**, version code **200164**, minimum Android API 30 and target API 36. It declares ABI and density split requirements, so these files alone do not form an installable Android app.

| File | Bytes | Class definitions |
| --- | ---: | ---: |
| classes.dex | 10,520,720 | 11,465 |
| classes2.dex | 10,848,536 | 10,932 |
| classes3.dex | 10,340,480 | 9,787 |
| classes4.dex | 9,431,808 | 9,399 |
| classes5.dex | 10,387,404 | 11,050 |
| classes6.dex | 10,942,236 | 9,073 |
| AndroidManifest.xml | 73,696 | — |
| resources.arsc | 2,045,504 | — |

All six DEX files passed their declared-length, embedded SHA-1, and Adler-32 checks. These establish internal consistency, not publisher authenticity. SHA-256 fingerprints are recorded in `input-integrity.json`.

Most of the baseball scoring UI and service implementation is in `classes3.dex`, including 1,725 class definitions under `com.gc.bats.scorekeeping`. Much of `classes.dex` is third-party code; class counts should not be interpreted as feature counts.

Method bodies were inspected through a custom DEX parser and instruction-reference extractor. Instruction boundaries decoded without overrun errors for the selected method bodies. This is not a complete Java/Kotlin decompilation or an execution test. Obtaining JADX through the configured network proxy failed because the proxy connection was refused; the analysis proceeded locally without it.

## 2. Scoring architecture

**Code-confirmed [E02, E03, E06, E07, E16]:**

- `ScoringPresenter` collects scoring choices and fielding information.
- `ScorekeepingDataUpdater` exposes operations such as pushing events, starting/finishing/canceling transactions, resolving runners, and undo/redo.
- `ScorekeepingServiceImpl` holds a `BaseballBridge.Compactor`, staged events, undo and redo stacks, a stream store, and game-state subjects.
- `ScorekeepingStateAccessor` exposes derived game outputs: play-by-play, line score, box score, stats, spray charts, and play detail.
- `FrontendUpdater` distributes updates to scoreboard, scoring, runners, line score, play-by-play, lineups, stats, substitutions, and other presenters.

Conceptual interpretation of these relationships:

```mermaid
flowchart TD
    A[Scoring input] --> B[Events and play transaction]
    B --> C[Rules engine bridge]
    C --> D[Updated game state]
    D --> E[Scoreboard, runners, lineup, stats, play-by-play]
    B --> F[Stream store and event sequence]
    F --> G[Offline synchronization]
```

The diagram summarizes interfaces, not a guarantee of one universal ordering across every feature-gated path. The service contains both older and `UseDataFlowV2` paths.

**Inference for this project:** keep scoring decisions and state transitions independent of the visual scorekeeper. Use the same game history to produce spectator views and statistics. The missing engine prevents proving its full replay and compaction semantics.

## 3. Pitch entry and ball-in-play flow

**Code-confirmed [E03, E04, E19]:** the menu is a series of screens rather than one flat result picker. Observed screens cover initial pitch options, ball-in-play type, ball-in-play outcome, dropped-third-strike cause/result, illegal pitches, placing a batter on base, sacrifice-bunt-safe outcomes, pitch style, and pitch velocity.

Observed pitch-result constants include:

- Ball and intentional ball.
- Looking and swinging strikes.
- Foul, foul bunt, and foul tip.
- Ball in play and illegal pitch.

The ball-in-play type screen explicitly references ground ball, hard ground ball, fly ball, line drive, bunt, and pop fly. Outcome handling references singles, doubles, triples, home runs, fielder's choice, errors, batter outs, sacrifice variants, infield fly, and offensive interference. Extended results include double and triple plays.

Menu availability depends on `PitchActionContext`. For example, the initial screen consults flags for foul tip, dropped third strike, balk, illegal pitch, and placing a batter. The result screen consults flags for double/triple plays, fielder's choice variants, and sacrifice opportunities.

**Meaning:** the UI receives contextual eligibility from the engine. It does not simply expose every possible scoring action at every moment.

**Unknown:** the complete eligibility formulas, including their baseball/softball and league-rule variations. A reference to `getDroppedThirdStrike()` does not establish the exact count/base/out conditions used internally.

## 4. Fielding and batted-ball detail

**Code-confirmed [E03]:** `ScoringPresenter` includes `handleFielders`, `handleEventDefenders`, `addDefendersToEvents`, `processBallInPlayEvent`, and home-run-specific handling. Referenced defender models include `Defender.XYLocation`.

Home-run location constants include left, center, right, and inside the park. Error handling is distinct from a normal hit outcome. These are richer inputs than a final score or hit total.

**Inference for this project:** represent the contact type, outcome, involved defenders, and optional location independently. That would support fielding attribution and spray charts without forcing the UI to collect every optional field on every pitch.

**Unknown:** the engine's exact attribution rules for assists, putouts, errors, RBI, or earned runs. Their presence in stats does not prove how every edge case is scored.

## 5. Runner resolution and grouped plays

**Code-confirmed [E02, E03, E05, E06]:**

- The service supports `startEventTransaction`, `finishEventTransaction`, and `cancelEventTransaction`.
- The V2 finishing method wraps staged events in `BaseballEvent.Transaction` when there are multiple events.
- Canceling a transaction clears scratch state and staged events.
- The bridge has separate `markSafe`, `markOut`, `markSentBack`, and `markViolation` calls.
- `EventHandlerHelper.eventRequiresBaserunnerTransaction` checks ball-in-play and dropped-third-strike event types.
- Runner menus receive separate safe and out action contexts.

Observed advancement reasons include stolen base, wild pitch, passed ball, defensive indifference, error, same pitch, same error, last play, throw, and other advance. Observed out reasons include caught stealing, pickoff, appeal, interference, and out on last play. Additional flavors include tagged up, caught tagging, failed to tag, doubled off, and left base early.

These distinctions preserve *why* a runner moved or was retired. That information can affect stats even when the final occupied bases are identical.

**Inference for this project:** treat a play as provisional while its participants are being resolved, and commit the grouped changes together. Cancel should restore the prior game state. This follows the visible transaction model; the exact engine rollback algorithm remains unavailable.

## 6. Undo, redo, and historical corrections

**Code-confirmed [E02, E07, E10]:** there are two layers:

1. Engine undo/redo through `SabertoothEvent.MetaEvent` and `MetaEventCode.UNDO` / `REDO`.
2. Client undo actions for other changes, including placeholder players and renaming players.

`pushUndoAction` clears the redo stack. The service checks transaction state and engine availability when deciding whether undo/redo can be offered.

Historical outcome editing is a different workflow. The outcome picker passes an event ID and equivalent play type to `makeReplacementEvent`, then pushes the resulting meta-event. The accessor also exposes `fetchPossiblyMutatedAtBats` and `stateAccessorBeforeEvent`.

**Meaning:** correcting an earlier play is represented in relation to the original event, rather than merely overwriting current score totals.

**Inference:** historical edits can require refreshing affected at-bats and derived stats. The visible interfaces support this interpretation, but do not prove whether the engine recomputes the entire game, an affected suffix, or cached subsets.

## 7. Lineups and substitutions

**Code-confirmed [E08]:** substitution modes include batter, fielder, full substitution, pinch runner, courtesy runner, placing a runner, designated hitter, DHEE, and DP/Flex handling. The service references lineup operations including reorder, fill/clear a slot, fill/clear a position, set teams, substitute players, and confirm end of lineup.

The UI separately handles a current batter who is already on base with `REPLACE` and `SKIP` choices. Batting order, defensive positions, and occupied bases are distinct concepts in the visible model.

**Resource-confirmed:** QR-code lineup sharing/import exists in the UI text. It warns that scanning replaces the opponent lineup and cannot be done once scoring has begun [4159, 7026, 8717]. The backend implementation and all restrictions were not recovered here.

**Inference for this project:** a single mutable roster array is unlikely to represent substitutions accurately enough. Batting slots, defensive assignments, runner identity, and special roles need their own records/history.

## 8. Manual adjustments and finalization

**Code-confirmed [E09]:** manual overrides collect both team scores, inning, inning half, balls, strikes, and outs, then create a `BaseballEvent.ManualOverrides` event. Adjustments therefore enter the scoring event system.

**Code-confirmed [E11]:** finalization has separate winner, loser, save, and home/away blown-save selections. It calculates or retrieves eligible pitcher choices and constructs decision events. The service also includes deletion of previous pitcher-decision events when relevant.

**Unknown:** the exact win/save eligibility formulas and the complete behavior when reopening or rescoring a finalized game. Those should not be inferred solely from method names.

## 9. Statistics, pitch counts, and spray charts

**Code-confirmed [E07, E12, E17, E18]:** accessors expose full stats, player/team stats, inning stats, box-score situation, line score, and spray charts. The supplied stat glossary is extensive.

Observed categories include:

| Category | Examples in supplied code |
| --- | --- |
| Batting | PA, AB, H, extra-base hits, RBI, BB, SO, AVG, OBP, SLG, OPS, BABIP |
| Situational batting | RISP, two-out RBI, pitches seen, six-plus-pitch appearances, quality at-bats |
| Pitching | Pitches, strikes, balls, IP, BF, ER, ERA, WHIP, strikeouts, walks, decisions |
| Pitch analysis | First-pitch strikes, pitch-type frequency, swing/miss rates, average/top velocity |
| Fielding/catching | Errors, assists, putouts, double/triple plays, caught stealing, passed balls |
| Batted balls | Ground/fly/line-drive classifications, hard-hit and weak-contact groupings |

The glossary explicitly describes quality at-bats using conditions including three pitches after two strikes, six-plus-pitch at-bats, extra-base hits, hard-hit balls, walks, sacrifice bunts, and sacrifice flies. This is a recovered description, not an executed verification of its calculation.

Pitch-type and velocity collection are configurable in `PitchMenuSettings`. `GameSettings` also has innings per game, two pitch alert limits, short-fielder type, and a game clock setting. Pitch counts have a breakdown screen and Pitch Smart guidance; analytics reference manual velocity and Pocket Radar inputs.

**Unknown:** complete metric formulas, rounding, earned-run reconstruction, innings-based ERA normalization, and Pitch Smart enforcement. The presence of guidance and alert limits does not establish automatic rest-rule enforcement.

## 10. Offline events, sequence numbers, and shared game versions

**Code-confirmed [E02, E13, E14, E15]:**

- `GameStreamEvent` has an ID, game-stream ID, event-data string, sequence number, and timestamp.
- `OfflineGameStreamEvent` has event data, sequence number, stream dependency, and sync metadata.
- A queued-game-stream-event type is present.
- `saveEventV2` compares the engine-returned event ID with the submitted event ID, throws on a mismatch, and otherwise saves with the engine-provided sequence number.
- `GameStreamEventRepositoryImpl.sync` has feature-gated paths; the visible legacy path posts through an authenticated network provider and then updates its datastore.
- `OfflineSyncServiceImpl.isGameStreamInSync` combines queue observations for the game stream and its events.

**Resource-confirmed:** the UI explicitly says scoring data will sync when the device returns online [7076]. It also warns about stale data while offline and offers scoring a new version [5334]. Another message explains that one party can score a shared game stream for both teams, and that another party starting separately stops stats being shared across the parties [7903].

**Meaning:** local event history and sync status are first-class concerns. The supplied material supports a shared stream with a single scoring party and alternative game versions; it does not establish automatic merging of concurrent scorekeepers into one canonical history.

**Unknown:** transport details for spectator updates, conflict-resolution algorithms, exact retry/backoff behavior, delivery guarantees, server deduplication, event JSON schemas, and server-side rules. No GameChanger service was contacted or tested.

## 11. Other visible feature areas

The supplied classes/resources also indicate player cards, scorebook/PDF generation, lineup reuse, pitch-count reports, game alerts, video state, and streaming-scoreboard integration. Resource text references live audio play announcements, MaxPreps box-score syncing, league pitch-count CSV reports, continuous lineups, and lineup recommendations.

These are an inventory of visible client capabilities. Resource descriptions of recommendation logic are product copy, not recovered algorithms. Subscription and feature gates mean availability cannot be assumed. Video encoding, automatic highlight generation, and announcement generation were not reverse engineered in this pass.

## 12. Design implications for Diamond Program — no implementation

Based on the repository README inspected earlier, Diamond Program already has game scheduling, inning run entry, box-score entry, and pitch-count integration. The following is an independent design proposal, not a claim that GameChanger uses these exact tables or algorithms:

1. **Game history:** retain identifiable, ordered events and an explicit game-stream/version identity.
2. **Current state:** derive inning/half, count, outs, bases, active batter/pitcher, and score from scoring history.
3. **Play transaction:** group the pitch/contact, fielding detail, and runner decisions into one committed play.
4. **Corrections:** distinguish undoing the last action, replacing an old play, and manually overriding game state.
5. **Lineup history:** model batting order, defensive positions, substitutions, and runner replacements independently.
6. **Derived outputs:** build play-by-play, line score, box score, pitch counts, and spray charts from consistent scoring records.
7. **Offline operation:** retain pending local events and display whether the game is synchronized. Select a clear ownership/version policy before supporting multiple scoring devices.

Future validation should cover loaded-base walks, third-out run timing, double-play ordering, dropped-third-strike eligibility, courtesy runners, canceled multi-runner plays, edits that change later state, offline retries, and reopening a final game. These are recommended tests for a future implementation; none were executed against GameChanger here.

## 13. Current missing material and next pass

The second upload supplies the previously missing `BaseballBridge.Compactor`, `BaseballStateAccessor`, `ScorekeepingState`, and `BaseballEvent` definitions. The newer `com.gc.data.sabertoothbats.pub.BatsStateAccessor` definition is still absent from the six supplied DEX files, although nested classes referencing it were present in the earlier upload. This does not block analysis of the recovered older bridge.

The asset screenshot shows JavaScript files named `entrypoint`, `bats_entrypoint`, `multisport_entrypoint`, and `pdf_generator_bundle`. Windows appears to be hiding the `.js` extensions; the recovered code explicitly names `assets/entrypoint.js` and `assets/pdf_generator_bundle.js`.

For the next pass, upload:

1. **`entrypoint.js`** — the confirmed bundle loaded by the recovered baseball bridge.
2. **`bats_entrypoint.js`** — a likely additional baseball bundle based on its name and the newer package references; its exact role remains unverified until inspection.
3. **`pdf_generator_bundle.js`** — useful for the scorebook/PDF workflow.
4. **`multisport_entrypoint.js`**, optionally, for basketball and other sports after baseball.

The screenshot sizes are all below the 32 MiB transfer limit. A ZIP containing these JavaScript files should also be small enough. Do not rename their contents or execute them locally; just upload the files. No more language/configuration APKs are needed for this next step.

## 14. Second-upload findings: bridge contract and recovered models

### What the additional files contain

`classes4.dex` contains 1,039 definitions under `com.gc`, including the scoring bridge, JavaScript runtime wrappers, baseball event/state models, and related feature classes. `classes5.dex` and `classes6.dex` contain no definitions under the `com.gc` namespace. That namespace result does not rule out app-related code with obfuscated names, but these two files do not supply the named scoring types we were seeking.

The second-pass parser decoded 9,584 method bodies/definitions in the selected first-party class inventory with no instruction-overrun errors. Abstract methods have no body. This count is not a behavioral test.

The new evidence is in `pass2-engine-evidence.json`; model declarations and enum serialization annotations are in `engine-models.json`. Each bridge method record includes its DEX offset and referenced instructions. The schema export includes 210 model/bridge class definitions and their superclasses, so inherited fields can be followed explicitly. A missing `SerializedName` annotation is recorded as null; no untested global Gson naming policy is assumed.

### Confirmed JavaScript execution path

The following are direct observations in `classes4.dex`:

| Location | Observed behavior |
| --- | --- |
| `Bridge` constructor, offset `0x4d1e18` | Creates `J2V8Engine`, loads `assets/entrypoint.js`, and prepares a cached controller |
| `BaseballBridge.Compactor` constructor, `0x4ba484` | Supplies the controller name `baseball.usingCompactor` and a game context |
| `JsEngineExtKt.loadBundle`, `0x4b38f0` | Starts the engine, establishes a `window` binding and console shim, then executes bundle content |
| `Compactor.pushAndFetch` callback, `0x4b9690` | Invokes JavaScript method `pushAndFetch` with an event |
| `Compactor.pushBatchToScratchAndFetch` callback, `0x4b97ac` | Invokes `pushBatchToScratchAndFetch` with a list of events |
| `Compactor.clearScratchAndFetch` callback, `0x4b9034` | Invokes `clearScratchAndFetch` |
| `Compactor.markSafe` callback, `0x4b9528` | Invokes `markSafe` with the runner ID |

This confirms that important scoring operations cross into JavaScript. Inspecting only the DEX wrappers cannot recover their full implementation. It also identifies `entrypoint.js` as a concrete next input instead of merely guessing from asset names.

The asset's JavaScript may run independently of Android with a suitable host, but that is a hypothesis until its contents, exports, and dependencies are inspected. No bundle was executed in this pass.

### Game state is composed of several separate models

| Model | Recovered instance fields |
| --- | --- |
| `GameSituation` | balls, strikes, outs, inning, inning half, scores, baserunners |
| `FieldSituation` | batting team ID, fielding team ID, batter, fielders, baserunners, field-situation stats |
| `ScorekeepingState` | home/away IDs, situation, field situation, lineups, fielders, DH map, DP/Flex map, last-event info, scored-on-last-event list, pitch-action context |
| `TeamLineup` | batters and current index |
| `GameContext` | age group, sport, innings per game, player names, event sanity checking, backwards-compatible sent-back-runner setting |

The current batter is fetched through the batting team's lineup and its current-batter method. `currentBatterIsOnBase` uses the current batter ID and a runner/base lookup. These are recovered convenience methods; count progression, forced advances, and other rule calculations still cross the JavaScript boundary.

The separate last-event and scored-on-last-event records explain how the UI can distinguish a state snapshot from the changes associated with the latest action. How every list is populated remains dependent on the engine.

### Event payload fields are now directly recoverable

| Event detail model | Recovered fields |
| --- | --- |
| Pitch attributes | result, advancesCount, advancesRunners, speed, style, pitchSpeedProvider |
| Ball-in-play attributes | playType, playResult, extendedPlayResult, flavor, defenders, homeRunLocation |
| Baserunning attributes | runnerId, base, playType, flavor, defenders |
| Defender | position, error flag, optional XY location |
| Base event | ID, created-at value, compactor attributes; baseball events add an event code |
| Compactor attributes | component stream |
| Transaction | child events, with `_events` explicitly serialized as `events` |

Pitch-count advancement and runner advancement are separate flags. This establishes model support for separating these effects; their defaults and all callers must be checked before assigning precise scoring semantics to every combination.

Explicit Gson annotations confirm serialized labels including `strike_looking`, `strike_swinging`, `ground_ball`, `hard_ground_ball`, `fielders_choice`, `sacrifice_fly_error`, and `wild_pitch`. Two noteworthy field aliases are `homeRunLocation` → `hrLocation` and baserunning `flavor` → `playFlavor`.

These are recovered client schema facts, not a tested end-to-end network request schema. Null omission, constructor defaults, version wrappers, and server validation remain unverified.

### Corrections have more structure than undo/redo alone

The recovered `MetaEventCode` enum declares **DELETE, EDIT_GROUP, INSERT, REDO, REPLACE, TRANSACTION, UNDO**. `ReplaceEvent` has `deleteIds` and replacement `events`; `EditGroupEvent` has an event list. The compactor's component-stream enum declares **HEAD, MAIN, TAIL**.

The exact algorithm and ordering semantics of those streams are not exposed by their enum names. They should not be equated with network synchronization states or Git branches.

The native wrappers also expose JavaScript accessors named `possiblyMutatedAtBats` and `makeReplacementEvent`. This strengthens the earlier finding that historical corrections can affect derived at-bat outputs. It still does not establish the precise invalidation/replay strategy.

### Scratch and committed results have different contracts

| Returned model | Recovered fields |
| --- | --- |
| `ScorekeepingPushResultState` | scorekeepingState, undoRedoAvailability, animationOperations, sequenceNumberPair |
| `ScorekeepingScratchResultState` | scorekeepingState, undoRedoAvailability, animationOperations, events |
| `ScorekeepingResultState` | scorekeepingState, undoRedoAvailability, animationOperations |
| `BaserunnerResolverResult` | animationOperations and events |

This confirms that runner resolution can return scoring events as well as animation instructions, and that a push result can carry the event/sequence pair used by persistence. The Android UI's runner animations are therefore distinct from the scoring events themselves.

**Design implication for Diamond Program:** keep presentation effects, provisional play state, committed events, and synchronization metadata separate. This is an independent design recommendation; nothing has been implemented.

### Additional enum cases recovered

Definitions reveal cases that were not referenced in the first three DEX files, including runner `DID_NOT_SCORE`, flavors `CAUGHT_BACKTRACKING` and `CAUGHT_RUNNING`, and `STRIKEOUT` as an end-at-bat reason. The event-code definition also declares player/team stat edits, player swaps, and replacement-batter operations.

Declaration does not prove the current UI exposes each case. The complete recovered enum fields and their explicit serialization annotations are retained in `engine-models.json`.

### Remaining boundary

The Android bridge, event schema, and state contracts are substantially clearer. We still have not inspected the JavaScript implementation of earned runs, RBI attribution, third-out timing, forced advances, dropped-third-strike eligibility, automatic inning changes, or statistical replay. Uploading the small bundles shown in the screenshot is the next useful step toward those functions.

## Work boundaries

All analysis outputs are outside `/workspace/baseball-tracker`. No project source, tests, manifests, lockfiles, dependencies, Git refs, or environment configuration were changed. The app was not run, and no production API calls were made. This report is a partial static reconstruction of the supplied client, with explicit evidence and missing portions; it is not a complete recovery of GameChanger's rules engine.
