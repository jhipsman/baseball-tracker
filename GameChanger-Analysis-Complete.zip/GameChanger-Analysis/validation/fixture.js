var _id=0,c;
function ev(code,attributes,stream){return {id:'analysis-'+(++_id),code:code,attributes:attributes||{},compactorAttributes:{stream:stream||'main'}};}
function push(code,attributes,stream){return c.pushAndFetch(ev(code,attributes,stream));}
function pitch(result,extra){return push('pitch',Object.assign({result:result},extra||{}));}
function setup(options){_id=0;var names={};for(var i=1;i<=12;i++){names['a'+i]={firstName:'Away',lastName:String(i)};names['h'+i]={firstName:'Home',lastName:String(i)};}c=new controllers.baseball.usingCompactor(Object.assign({sport:'baseball',ageGroup:'youth',inningsPerGame:7,playerNames:names,sanityCheckEvents:true},options||{}));push('set_teams',{homeId:'home',awayId:'away'},'head');for(var team of ['home','away']){var prefix=team==='home'?'h':'a';for(var j=1;j<=9;j++){push('fill_lineup',{teamId:team,playerId:prefix+j},'head');push('fill_position',{teamId:team,playerId:prefix+j,position:['P','C','1B','2B','3B','SS','LF','CF','RF'][j-1]},'head');}}return c;}
function sit(){return c.getLatestScorekeepingState().scorekeepingState;}
function stat(team,player,category,key,derived){return c.latestState().playerStat(team,player,category,key,derived!==false);}
function hit(result,type){push('pitch',{result:'ball_in_play'});return push('ball_in_play',{playType:type||'ground_ball',playResult:result,defenders:[]});}
function out(){return push('end_at_bat',{reason:'strikeout'});}
function manual(attrs){return push('override',attrs);}
function place(id,base){return push('place_runner',{runnerId:id,base:base});}
function runner(id,base,playType,flavor){return push('base_running',{runnerId:id,base:base,playType:playType,playFlavor:flavor});}
