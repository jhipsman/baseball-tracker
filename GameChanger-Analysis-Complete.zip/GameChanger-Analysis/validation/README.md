# Validation evidence

The original uploaded JavaScript bundles were executed in Node 24.19.0 using a fresh controller fixture for every scenario. Each bundle ran in a separate VM context with string/Wasm code generation disabled and no Node file/network APIs exposed to that context. Each evaluation had a timeout. The bundles themselves were not edited for these tests.

## Result

**48 scenarios per bundle, 96/96 checks passed.** The portable runner was also executed successfully against the same original uploaded files. No scenarios were skipped or disabled. These checks exercise the baseball compactor controller, not the Android UI or GameChanger services.

A separate scorebook export check generated a valid two-page PDF. PDF structure was checked with `pdfinfo`; extracted text contained both synthetic team headers. The regenerated sample is 425,675 bytes. See `pdf-result.json`, `pdfinfo.txt`, and `sample-scorebook.pdf`.

## Files

- `run.cjs`: dependency-free analysis runner.
- `fixture.js`: synthetic game setup and scoring helpers; no application integration.
- `core-cases.json`, `additional-cases.json`: scenario inputs and explicit expected values.
- `results-current.json`: final combined results from the portable runner.
- `core-results.json`, `additional-results.json`: earlier final results for the same case groups.
- `additional-observations.json`: exploratory traces, including explicit run/no-run adjudication and bundle differences. These are observations, not additional passed assertions.
- `initial-harness-results.json`: the initial run before representation fixes.
- `generate-pdf.cjs`: synthetic PDF reproduction.

## Reproduce

Use the exact assets from the uploaded APK; fingerprints are in `../input-integrity.json`. Keep analysis output outside any application checkout. With the extracted assets in a directory:

```sh
node validation/run.cjs /path/to/extracted/assets /tmp/gamechanger-validation
node validation/generate-pdf.cjs /path/to/extracted/assets /tmp/gamechanger-validation
pdfinfo /tmp/gamechanger-validation/sample-scorebook.pdf
```

Run these commands from the report directory. The first script requires `entrypoint.js` and `bats_entrypoint.js`; PDF generation requires `entrypoint.js` and `pdf_generator_bundle.js`. The archive does not duplicate those uploaded source bundles. No npm packages or project dependency installation is required. Node 24.19.0 was the runtime tested here.

## Investigation notes

The first core run had seven expectation-representation mismatches per bundle. Five counted base-map keys rather than occupied values; the engine retains keys with undefined values. Two expected a direct error-type property, while the engine encodes its type/reason in the Error message as JSON. The harness was corrected to count occupied values and decode the error message. Assertions remained in place; the engine was not changed. The corrected core cases passed 40/40 in each bundle.

The first PDF fixture supplied numeric jersey numbers. The renderer called a string method on one, so the synthetic metadata was corrected to string jersey numbers. The same original PDF bundle then produced the validated sample. This was not classified as an app defect.

An additional eight scenarios per bundle were then added to test earned-run distinctions, inherited responsibility, resolver follow-ups, missing rate stats, and the documented placed-runner attribution difference. All passed. The combined portable runner subsequently passed 48/48 for each bundle.

The direct force-out exploratory trace intentionally supplied a scored/safe adjudication and retained a run. A separate asserted scenario selected the no-score/send-back path and correctly removed the run. This distinction is described in `../RULES_AND_BEHAVIOR.md`; the trace does not establish a complete Android UI bug or exhaustive third-out validation.

## Scenario results

| Scenario ID | Behavior checked | entrypoint.js | bats_entrypoint.js |
| --- | --- | --- | --- |
| initial | Initial inning/count/lineup | Pass | Pass |
| four-balls | Four balls force a walk and advance the batter | Pass | Pass |
| third-strike | Third strike retires batter and resets count | Pass | Pass |
| two-strike-foul | Ordinary foul at two strikes adds a pitch without strikeout | Pass | Pass |
| two-strike-foul-bunt | Foul bunt can become strike three | Pass | Pass |
| two-strike-foul-tip | Foul tip can become strike three | Pass | Pass |
| three-outs | Third out switches to bottom and clears bases | Pass | Pass |
| two-halves | Bottom third out advances inning | Pass | Pass |
| no-regulation-stop | Rules state continues beyond configured regulation length | Pass | Pass |
| loaded-walk | Loaded-base walk forces exactly one run and an RBI | Pass | Pass |
| gap-walk | Walk does not force an isolated runner on second | Pass | Pass |
| hit-by-pitch | HBP awards first and does not count as AB | Pass | Pass |
| d3k-empty-first | Dropped-third-strike option with empty first at two strikes | Pass | Pass |
| d3k-first-occupied | Dropped-third-strike option blocked at occupied first with fewer than two outs | Pass | Pass |
| d3k-two-outs | Dropped-third-strike option available with occupied first at two outs | Pass | Pass |
| infield-fly | Infield fly option with first/second occupied and fewer than two outs | Pass | Pass |
| sac-fly | Sacrifice fly option with runner on third | Pass | Pass |
| balk-advance | Balk advances existing runners without placing batter | Pass | Pass |
| single | Single creates hit, AB and first-base runner | Pass | Pass |
| double-advance | Default double advances a first-base runner two bases | Pass | Pass |
| grand-slam | Bases-loaded home run scores four and credits four RBI | Pass | Pass |
| stolen-base | Stolen base changes base and credits SB | Pass | Pass |
| caught-stealing | Caught stealing removes runner and adds an out | Pass | Pass |
| courtesy-runner | Runner replacement preserves the occupied base | Pass | Pass |
| undo-redo | Undo and redo restore count state | Pass | Pass |
| transaction-undo | Grouped contact/pitch is undone as one action | Pass | Pass |
| scratch-cancel | Cancel provisional play restores state | Pass | Pass |
| historical-replace | Replacing earlier single with double recalculates runner state | Pass | Pass |
| manual-count | Manual override replaces count values | Pass | Pass |
| unset-batter | Strict sanity validation rejects pitch without a batter | Pass | Pass |
| occupied-destination | Strict validation rejects moving into another runner's base | Pass | Pass |
| earned-homer | Clean solo home run charged as one earned run | Pass | Pass |
| error-then-homer | Error runner followed by homer produces two runs, one earned | Pass | Pass |
| placed-runner-unearned | Manually placed runner scores without an earned run charge | Pass | Pass |
| quality-at-bat-once | Three pitches after two strikes qualify once despite more fouls | Pass | Pass |
| pitch-without-count | Count advancement can be disabled while pitch count increments | Pass | Pass |
| adult-illegal-pitch-context | Adult baseball disables illegal-pitch menu context | Pass | Pass |
| softball-illegal-pitch-context | Softball context allows illegal pitch as ball with empty bases | Pass | Pass |
| era-regulation-length | ERA scales by configured game length using real thirds of innings | Pass | Pass |
| ip-third | One recorded out is stored as one-third inning | Pass | Pass |
| passed-ball-er | Passed balls do not advance hypothetical earned bases | Pass | Pass |
| wild-pitch-er | Wild pitches can advance earned bases | Pass | Pass |
| inherited-walk-owner | Pitcher replaced at 2-0 retains responsibility for ensuing walk | Pass | Pass |
| resolver-bunt-out | Sacrifice-bunt resolver emits the batter out event | Pass | Pass |
| resolver-sendback-retracts-score | Runner sent back after a single retracts provisional run | Pass | Pass |
| resolver-dp-no-run | No-score runner decision plus double-play out closes inning with zero runs | Pass | Pass |
| undefined-zero-rate | Undefined rate stats are omitted instead of emitting NaN | Pass | Pass |
| placed-runner-version-difference | Bundles differ in pitcher run attribution for manually placed runner | Pass | Pass |
