// Analysis-only reproduction of the synthetic scorebook export.
'use strict';
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), assert = require('node:assert/strict');
if (!process.argv[2]) throw new Error('Usage: node generate-pdf.cjs <assets directory> [output directory]');
const assets = path.resolve(process.argv[2]), output = path.resolve(process.argv[3] || __dirname);
const context = vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } });
vm.runInContext('var window=this;var self=this;var global=this;var console={log(){},error(){}};', context);
for (const name of ['entrypoint.js', 'pdf_generator_bundle.js']) vm.runInContext(fs.readFileSync(path.join(assets, name), 'utf8'), context, { timeout: 5000, filename: name });
vm.runInContext(fs.readFileSync(path.join(__dirname, 'fixture.js'), 'utf8'), context, { timeout: 1000 });
const base64 = vm.runInContext(`
setup();hit('single');out();
var scorebook=c.latestState().scorebook;
var gameInfo={home_team_info:{teamId:'home',teamName:'Analysis Home',players:{}},away_team_info:{teamId:'away',teamName:'Analysis Away',players:{}},startTime:'2026-10-29 12:00:00'};
for(var team of ['home','away']){var info=team==='home'?gameInfo.home_team_info:gameInfo.away_team_info;for(var i=1;i<=12;i++)info.players[(team==='home'?'h':'a')+i]={firstName:team,lastName:String(i),number:String(i)};}
generateScorebookPdf(scorebook,gameInfo);`, context, { timeout: 10000 });
assert.equal(typeof base64, 'string');
assert.ok(!base64.startsWith('Error:'), base64);
const pdf = Buffer.from(base64, 'base64');
assert.ok(pdf.subarray(0, 8).toString('ascii').startsWith('%PDF-'));
assert.ok(pdf.subarray(-64).toString('ascii').includes('%%EOF'));
fs.mkdirSync(output, { recursive: true });
fs.writeFileSync(path.join(output, 'sample-scorebook.pdf'), pdf);
const result = { passed: true, bytes: pdf.length, header: pdf.subarray(0, 8).toString('ascii'), syntheticDataOnly: true };
fs.writeFileSync(path.join(output, 'pdf-result.json'), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
