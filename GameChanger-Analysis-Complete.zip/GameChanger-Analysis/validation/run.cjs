// Analysis harness only. Runs supplied bundles in memory; no project integration.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const assets = path.resolve(process.argv[2] || '');
const output = path.resolve(process.argv[3] || __dirname);
if (!process.argv[2]) throw new Error('Usage: node run.cjs <directory containing entrypoint.js and bats_entrypoint.js> [output directory]');
const fixture = fs.readFileSync(path.join(__dirname, 'fixture.js'), 'utf8');
const cases = ['core-cases.json', 'additional-cases.json'].flatMap(n => JSON.parse(fs.readFileSync(path.join(__dirname, n), 'utf8')));
const results = [];
for (const bundle of ['entrypoint.js', 'bats_entrypoint.js']) {
  const context = vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } });
  vm.runInContext('var window=this;var self=this;var global=this;var console={log(){},error(){}};', context);
  vm.runInContext(fs.readFileSync(path.join(assets, bundle), 'utf8'), context, { timeout: 5000, filename: bundle });
  vm.runInContext(fixture, context, { timeout: 1000 });
  for (const test of cases) {
    const row = { bundle, id: test.id, description: test.description, expected: test.expectedByBundle?.[bundle] ?? test.expected };
    try {
      row.actual = JSON.parse(vm.runInContext('JSON.stringify((function(){' + test.script + '})())', context, { timeout: 5000 }));
      assert.deepEqual(row.actual, row.expected);
      row.passed = true;
    } catch (error) {
      row.passed = false;
      row.error = { name: error.name, message: error.message };
    }
    results.push(row);
  }
  console.log(bundle + ': ' + results.filter(r => r.bundle === bundle && r.passed).length + '/' + cases.length + ' passed');
}
fs.mkdirSync(output, { recursive: true });
fs.writeFileSync(path.join(output, 'results-current.json'), JSON.stringify(results, null, 2));
process.exitCode = results.some(r => !r.passed) ? 1 : 0;
